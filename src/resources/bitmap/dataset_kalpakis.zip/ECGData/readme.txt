The ECG datasets that we used are from the following website:
http://www.physionet.org/physiobank/database

We picked data from those listed under ECG databases from the following 3 databases.

[Class 3] MIT-BIH Normal Sinus Rhythm Database
(http://www.physionet.org/physiobank/database/nsrdb/)

[Class 3] MIT-BIH Malignant Ventricular Arrhythmia Database
(http://www.physionet.org/physiobank/database/vfdb/)

[Class 3] MIT-BIH Supraventricular Arrhythmia Database
(http://www.physionet.org/physiobank/database/svdb/)

ECG readings corresponding to each subject in a particular category
is available in a single ascii file in the respective directory.
For more information on the data please look at the above mentioned websites.


There are 3 columns in each file.
1st column gives the time. (sampling at 8ms for 2seconds).
The 2nd and 3rd columns give two ECG signals. (we consider only 1 signal
for our experiments).


File organization and naming is as follows.

Directory      			Filename description
SupraVentricular	superven#.txt, where # is a number between 1 and 30

normal			normal#.txt, where # is a number between 1 and 18

MalignantVentricular	venarh#.txt, where # is a number between 1 and 22



